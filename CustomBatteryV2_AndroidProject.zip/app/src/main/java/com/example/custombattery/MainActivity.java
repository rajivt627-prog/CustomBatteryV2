package com.example.custombattery;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private Button toggle;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(40, 60, 40, 40);

        TextView title = new TextView(this);
        title.setText("⚡ Custom Battery V2");
        title.setTextSize(26);
        title.setPadding(0, 0, 0, 25);

        TextView info = new TextView(this);
        info.setText("Floating battery indicator using your photo.\n\nTap Start, allow 'Display over other apps', then the indicator will appear above other apps. Drag it anywhere.");
        info.setTextSize(17);
        info.setPadding(0, 0, 0, 30);

        toggle = new Button(this);
        toggle.setText("Start Floating Battery");

        box.addView(title);
        box.addView(info);
        box.addView(toggle);
        setContentView(box);

        toggle.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else {
                startService(new Intent(this, BatteryOverlayService.class));
                toggle.setText("Floating Battery Started");
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (toggle != null && Settings.canDrawOverlays(this)) {
            toggle.setText("Start Floating Battery");
        }
    }
}
