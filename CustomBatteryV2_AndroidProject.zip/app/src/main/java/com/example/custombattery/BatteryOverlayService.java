package com.example.custombattery;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.Locale;

public class BatteryOverlayService extends Service {
    private WindowManager wm;
    private View overlay;
    private TextView percent;
    private TextView bolt;
    private BroadcastReceiver receiver;

    @Override
    public void onCreate() {
        super.onCreate();
        startForegroundNotification();
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        createOverlay();
        receiver = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) { updateBattery(i); }
        };
        IntentFilter f = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(receiver, f);
        updateBattery(registerReceiver(null, f));
    }

    private void startForegroundNotification() {
        String channel = "battery_overlay";
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(channel, "Custom Battery", NotificationManager.IMPORTANCE_LOW));
        }
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, channel)
                : new Notification.Builder(this);
        nb.setContentTitle("Custom Battery is active")
          .setContentText("Floating battery indicator is running")
          .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
          .setContentIntent(pi)
          .setOngoing(true);
        startForeground(22, nb.build());
    }

    private void createOverlay() {
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);

        FrameLayout root = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(235, 16, 19, 28));
        bg.setCornerRadius(45);
        bg.setStroke(3, Color.rgb(57,231,95));
        root.setBackground(bg);
        root.setPadding(8,8,8,8);

        ImageView photo = new ImageView(this);
        photo.setImageResource(R.drawable.character);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        photo.setBackground(circle);
        photo.setClipToOutline(true);
        photo.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View v, android.graphics.Outline o) {
                o.setOval(0,0,v.getWidth(),v.getHeight());
            }
        });

        percent = new TextView(this);
        percent.setTextColor(Color.WHITE);
        percent.setTextSize(13);
        percent.setTypeface(null, android.graphics.Typeface.BOLD);
        percent.setGravity(Gravity.CENTER);

        bolt = new TextView(this);
        bolt.setText("⚡");
        bolt.setTextColor(Color.YELLOW);
        bolt.setTextSize(15);
        bolt.setGravity(Gravity.CENTER);

        root.addView(photo, new FrameLayout.LayoutParams(58,58));
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(58, 25);
        pp.leftMargin = 0; pp.topMargin = 57;
        root.addView(percent, pp);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(30,30,Gravity.RIGHT|Gravity.TOP);
        root.addView(bolt, bp);

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                74, 88, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.RIGHT;
        lp.x = 18; lp.y = 180;

        root.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX=e.getRawX(); downY=e.getRawY();
                    startX=lp.x; startY=lp.y; return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    lp.x = startX - (int)(e.getRawX()-downX);
                    lp.y = startY + (int)(e.getRawY()-downY);
                    wm.updateViewLayout(root, lp); return true;
                }
                return true;
            }
        });

        overlay = root;
        wm.addView(overlay, lp);
    }

    private void updateBattery(Intent i) {
        if (i == null || percent == null) return;
        int level = i.getIntExtra("level", -1);
        int scale = i.getIntExtra("scale", 100);
        int p = scale > 0 ? Math.round(level * 100f / scale) : level;
        boolean charging = i.getIntExtra("status", -1) == android.os.BatteryManager.BATTERY_STATUS_CHARGING
                || i.getIntExtra("status", -1) == android.os.BatteryManager.BATTERY_STATUS_FULL;
        percent.setText(String.format(Locale.US, "%d%%", p));
        bolt.setVisibility(charging ? View.VISIBLE : View.GONE);
        int stroke = p <= 15 ? Color.RED : (p <= 30 ? Color.YELLOW : Color.rgb(57,231,95));
        GradientDrawable bg = (GradientDrawable) overlay.getBackground();
        bg.setStroke(3, stroke);
    }

    @Override public int onStartCommand(Intent i, int flags, int id) { return START_STICKY; }

    @Override public void onDestroy() {
        if (receiver != null) unregisterReceiver(receiver);
        if (overlay != null && wm != null) wm.removeView(overlay);
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent i) { return null; }
}
