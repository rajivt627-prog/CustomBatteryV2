CUSTOM BATTERY V2 — REAL ANDROID FLOATING OVERLAY

WHAT IT DOES
- Uses the supplied photo as the floating battery character.
- Reads Android battery percentage.
- Shows percentage on the indicator.
- Shows ⚡ while charging.
- Changes border color at low battery.
- Can be dragged around the screen.
- Runs as a foreground service.

IMPORTANT
This is a real Android project, not just HTML. Acode can edit the source files, but Acode alone normally does not compile an Android APK unless you have an Android build environment/plugin available.

BUILD
Open the project in Android Studio/another Android build environment and build an APK.
Then install it on the phone.

FIRST RUN
1. Open the app.
2. Tap Start Floating Battery.
3. Android will ask for "Display over other apps" permission.
4. Enable it.
5. Return to the app.
6. The floating indicator appears.
7. Drag it to any position.

NOTE
This version intentionally uses a floating overlay rather than replacing Samsung's native status-bar battery icon. Replacing the native icon requires deeper system/UI modification and is device/One UI dependent.
